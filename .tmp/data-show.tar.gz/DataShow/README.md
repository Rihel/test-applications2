# @spaas/data-show

简介：统计数据显示
![截图](./screenshot.png)
主要显示头部统计数据
